<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'App'
}
</script>

<style>
body, html {
  height: 100%;
}

#app{
  height: 100%;
}

</style>
